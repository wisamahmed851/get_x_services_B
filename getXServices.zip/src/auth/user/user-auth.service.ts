import {
  BadRequestException,
  Injectable,
  NotFoundException,
  InternalServerErrorException,
  UnauthorizedException,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import * as bcrypt from 'bcryptjs';
import { JwtService } from '@nestjs/jwt';
import { User } from 'src/users/entity/user.entity';
import { Role } from 'src/roles/entity/roles.entity';
import { UserRole } from 'src/assig-roles-user/entity/user-role.entity';
import { UpdateProfileDto, UserRegisterDto } from './dtos/user-auth.dto';
import { cleanObject, sanitizeUser } from 'src/common/utils/sanitize.util';
import { response } from 'express';
import { City } from 'src/city/entity/city.entity';
import { Zone } from 'src/zone/entity/zone.entity';
import { UserDetails } from 'src/users/entity/user_details.entity';
import { ConfigService } from '@nestjs/config';
import { plainToInstance } from 'class-transformer';

@Injectable()
export class UserAuthService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,

    private jwtService: JwtService,

    @InjectRepository(Role)
    private roleRepo: Repository<Role>,

    @InjectRepository(UserRole)
    private userRoleRepo: Repository<UserRole>,

    @InjectRepository(City)
    private cityRepo: Repository<City>,

    @InjectRepository(Zone)
    private zoneRepo: Repository<Zone>,

    @InjectRepository(UserDetails)
    private userDetailsRepo: Repository<UserDetails>,

    private readonly dataSource: DataSource,
    private readonly configService: ConfigService,
  ) { }
  async onModuleInit() {
    // Warm up bcrypt
    await bcrypt.compare('warmup', await bcrypt.hash('warmup', 10));

    // Warm up JWT
    this.jwtService.sign({ sub: 1, email: 'warmup@example.com' });

    // Warm up DB entity serialization
    plainToInstance(User, this.userRepository.create({ name: 'warmup' }));
    Logger.log('UserAuthService initialized and warmed up');
  }
  private handleUnknown(err: unknown): never {
    if (
      err instanceof BadRequestException ||
      err instanceof NotFoundException
    ) {
      throw err;
    }
    throw new InternalServerErrorException('Unexpected error occurred', {
      cause: err as Error,
    });
  }

  async register(body: UserRegisterDto) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Check if email already exists
      const oldUsers = await queryRunner.manager.find(User, {
        where: { email: body.email },
      });

      if (oldUsers.length > 0) {
        throw new BadRequestException('User with this email already exists');
      }

      // Hash password
      if (body.password) {
        body.password = await bcrypt.hash(body.password, 10);
      }

      // Validate city
      if (body.city_id) {
        const city = await queryRunner.manager.findOne(City, { where: { id: body.city_id } });
        if (!city) throw new NotFoundException('City not found');
      }

      // Validate zone
      if (body.zone_id) {
        const zone = await queryRunner.manager.findOne(Zone, { where: { id: body.zone_id } });
        if (!zone) throw new NotFoundException('Zone not found');
      }

      // Create and save user
      const user = queryRunner.manager.getRepository(User).create({
        name: body.name,
        email: body.email,
        password: body.password,
        phone: body.phone,
        gender: body.gender,
        zone_id: body.zone_id,
        city_id: body.city_id,
      });
      const savedUser = await queryRunner.manager.save(User, user);

      // Assign role
      let role: Role | null = null;
      if (body.role === 'customer' || body.role === 'provider') {
        role = await queryRunner.manager.findOne(Role, {
          where: { name: body.role },
          select: { id: true, name: true },
        });
 
        if (!role) throw new BadRequestException('Role Not Found');

        const userRole = queryRunner.manager.getRepository(UserRole).create({
          user_id: savedUser.id,
          user: savedUser,
          role_id: role.id,
          role: role,
        });
        const savedUserRole = await queryRunner.manager.save(UserRole, userRole);
        if (!savedUserRole) {
          throw new InternalServerErrorException('Failed to assign role to user');
        }
      }

      // Extra provider details
      if (body.role === 'provider') {
        if (!body.identity_no || !body.identity_validity_date) {
          throw new BadRequestException('Identity number and validity date are required for providers');
        }
        if (!body.identity_card_front_url && !body.identity_card_back_url) {
          throw new BadRequestException('Identity card images are required for providers');
        }

        const userDetails = queryRunner.manager.getRepository(UserDetails).create({
          identity_no: body.identity_no,
          identity_validity_date: body.identity_validity_date,
          identity_card_front_url: body.identity_card_front_url,
          identity_card_back_url: body.identity_card_back_url,
          user: savedUser,
          user_id: savedUser.id,
        });
        await queryRunner.manager.save(UserDetails, userDetails);
        await queryRunner.commitTransaction();
        return {
          success: true,
          message: 'User is registered and logged in successfully',
          data: {
            user: {
              id: savedUser.id,
              name: savedUser.name,
              email: savedUser.email,
              phone: savedUser.phone,
            }
          },
        };
      }

      await queryRunner.commitTransaction();

      // Fetch user roles for token payload
      const roles = await this.userRoleRepo.find({
        where: { user_id: savedUser.id },
        relations: ['role'],
        select: { role: { id: true, name: true } },
      });

      const roleNames = roles.map(r => r.role.name);
      const payload = {
        sub: savedUser.id,
        email: savedUser.email,
        roles: roleNames,
      };


      const [token, refresh_token] = await Promise.all([
        this.jwtService.signAsync(payload, { expiresIn: '30m' }),
        this.jwtService.signAsync(payload, { expiresIn: '7d' }),
      ]);

      // Save tokens to DB
      savedUser.access_token = token;
      savedUser.refresh_token = refresh_token;
      await this.userRepository.save(savedUser);

      const userRole = roles[0]?.role;

      // Final response (same shape as login)
      return {
        success: true,
        message: 'User is registered and logged in successfully',
        data: {
          access_token: token,
          refresh_token: refresh_token,
          role: userRole ? userRole.name : null,
        },
      };
    } catch (err) {
      if (queryRunner.isTransactionActive) {
        await queryRunner.rollbackTransaction();
      }
      console.error('Registration error:', err);
      this.handleUnknown(err);
    } finally {
      await queryRunner.release();
    }
  }


  async validateUser(email: string, password: string) {
    try {
      if (!email || !password) {
        throw new BadRequestException('Email and password are required');
      }

      const user = await this.userRepository.findOne({
        where: { email: email.toLowerCase().trim() },
      });

      if (!user) {
        throw new BadRequestException('Invalid credentials');
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        throw new BadRequestException('Invalid password');
      }

      return user;
    } catch (err) {
      this.handleUnknown(err);
    }
  }

  async login(user: User) {
    try {
      // Run DB query and token generation in parallel
      const [roles, token, refresh_token] = await Promise.all([
        this.userRoleRepo.find({
          where: { user_id: user.id },
          relations: ['role'],
          select: { role: { id: true, name: true } },
        }),
        this.jwtService.signAsync(
          { sub: user.id, email: user.email }, // temporary payload (roles added later)
          { expiresIn: '30m' }
        ),
        this.jwtService.signAsync(
          { sub: user.id, email: user.email }, // temporary payload (roles added later)
          { expiresIn: '7d' }
        ),
      ]);

      // Save tokens
      user.access_token = token;
      user.refresh_token = refresh_token;
      await this.userRepository.save(user);

      const userRole = roles[0]?.role;

      return {
        success: true,
        message: 'User has been successfully logged in',
        data: {
          access_token: token,
          refresh_token: refresh_token,
          // user: plainToInstance(User, user),
          role: userRole ? { id: userRole.id, name: userRole.name } : null,
        },
      };
    } catch (err) {
      this.handleUnknown(err);
    }
  }


  async currentLocation(userId: number, body: { langitude: number; latitude: number }) {
    try {
      if (!body.langitude || !body.latitude) {
        throw new BadRequestException('Longitude and latitude are required');
      }

      const result = await this.userRepository
        .createQueryBuilder()
        .update(User)
        .set({
          location: () => `ST_SetSRID(ST_MakePoint(${body.langitude}, ${body.latitude}), 4326)::geography`,
        })
        .where("id = :id", { id: userId })
        .returning(`
        id,
        name,
        email,
        phone,
        address,
        ST_AsText(location) as location,
        ST_X(location::geometry) as longitude,
        ST_Y(location::geometry) as latitude
      `)
        .execute();

      if (!result.affected) {
        throw new NotFoundException("User not found");
      }

      const updatedUser = result.raw[0];

      return {
        success: true,
        message: 'User location updated successfully',
        data: {
          // location: updatedUser.location, // "POINT(lng lat)"
          User: {
            id: updatedUser.id,
            name: updatedUser.name,
            email: updatedUser.email,
            phone: updatedUser.phone,
            address: updatedUser.address,
            longitude: updatedUser.longitude,
            latitude: updatedUser.latitude,
          },
        },
      };
    } catch (err) {
      console.error('Error updating user location:', err);
      this.handleUnknown(err);
    }
  }


  async refreshToken(refreshToken: string) {
    const user = await this.userRepository.findOne({ where: { refresh_token: refreshToken } });

    if (!user) {
      throw new UnauthorizedException('Invalid referesh token');
    }
    try {
      const role = await this.userRoleRepo.find({ where: { user_id: user.id }, relations: ['role'] })
      const roleNames = role.map((r) => r.role.name);
      const paylod = this.jwtService.verify(refreshToken, {
        secret: 'user-secret-key',
      });

      const newAccessToken = this.jwtService.sign({
        sub: user.id,
        email: user.email,
        roles: roleNames,
      },
        { expiresIn: '30m' },
      );

      user.access_token = newAccessToken;
      await this.userRepository.save(user);
      // const { password, access_token, refresh_token, fcm_token, ...cleanUser } = user;
      return {
        success: true,
        message: 'Token refreshed successfully',
        data: {
          access_token: newAccessToken,
          user: sanitizeUser(user),
        },
      };

    } catch (err) {
      console.error('Error refreshing token:', err);
      this.handleUnknown(err);
    }
  }

  async profile(user: User) {
    try {
      const loginUser = await this.userRepository.findOne({
        where: { id: user.id },
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
          address: true,
          gender: true,
          street: true,
          district: true,
          image: true,
          status: true,
          created_at: true,
          updated_at: true,
        },
      });

      if (!loginUser) {
        throw new NotFoundException('User not found');
      }

      return {
        success: true,
        message: 'User profile fetched successfully',
        data: loginUser,
      };
    } catch (err) {
      this.handleUnknown(err);
    }
  }

  async profileUpdate(user: User, body: UpdateProfileDto) {
    try {
      const exist = await this.userRepository.findOne({
        where: { id: user.id },
      });
      if (!exist) {
        throw new NotFoundException('User Not Found');
      }
      if (body.name !== undefined) exist.name = body.name;
      if (body.street !== undefined) exist.street = body.street;
      if (body.district !== undefined) exist.district = body.district;
      if (body.address !== undefined) exist.address = body.address;
      if (body.gender !== undefined) exist.gender = body.gender;
      if (body.phone !== undefined) exist.phone = body.phone;
      if (body.image !== undefined) exist.image = body.image;

      const savedUser = await this.userRepository.save(exist);

      return {
        success: true,
        message: 'Password updated successfully',
        data: savedUser,
      };
    } catch (err) {
      this.handleUnknown(err);
    }
  }

  async changePassword(
    body: { oldPassword: string; newPassword: string },
    user: User,
  ) {
    try {
      const { oldPassword, newPassword } = body;

      if (!oldPassword || !newPassword) {
        throw new BadRequestException(
          'Both old and new passwords are required',
        );
      }

      const loginUser = await this.userRepository.findOne({
        where: { id: user.id },
      });

      if (!loginUser) {
        throw new NotFoundException('User not found');
      }

      const matched = await bcrypt.compare(oldPassword, loginUser.password);
      if (!matched) {
        throw new BadRequestException('Old password is incorrect');
      }

      if (newPassword.trim().length < 6) {
        throw new BadRequestException(
          'New password must be at least 6 characters long',
        );
      }

      loginUser.password = await bcrypt.hash(newPassword.trim(), 10);
      await this.userRepository.save(loginUser);

      return {
        success: true,
        message: 'Password updated successfully',
        data: {},
      };
    } catch (err) {
      this.handleUnknown(err);
    }
  }

  async modeChnage(user: User) {
    try {
      const currentUser = await this.userRepository.findOne({
        where: { id: user.id },
      });
      if (!currentUser) throw new NotFoundException('Driver not Found');

      currentUser.isOnline = currentUser.isOnline === 1 ? 0 : 1;
      const saved = await this.userRepository.save(currentUser);
      const is = currentUser.isOnline === 1 ? 'Online' : 'Ofline';
      return {
        success: true,
        message: `Driver is ${is} now`,
        data: saved,
      };
    } catch (err) {
      this.handleUnknown(err);
    }
  }

  async logout(data: User) {
    try {
      const user = await this.userRepository.findOne({
        where: { id: data.id },
      });

      if (!user) {
        throw new NotFoundException('User not found');
      }

      user.access_token = '';
      await this.userRepository.save(user);

      return {
        success: true,
        message: 'User has been logged out successfully',
        data: {},
      };
    } catch (err) {
      this.handleUnknown(err);
    }
  }

}
