export enum Register {
  CUSTOMER = 'customer',
  DRIVER = 'driver',
}
