import { Controller } from '@nestjs/common';

@Controller('user-wallet')
export class UserWalletController {}
